(function () {
    'use strict';
    angular.module("ice", []);
})();
